<?php
/**
 + Created by	:	JoomBah Team
 * Company		:	ISDS Sdn Bhd
 + Contact		:	www.joombah.com , support@joombah.com
 * Created on	:	26 December 2010
 * Author 		:	JoomBah Team
 * Tested by	: 	Zaki
 + Project		: 	Job site
 * File Name	:	controllers/payment.php
 * License		:	GNU General Public License version 3, or later
 ^ 
 * Description	: 	Entry point for the component (jbjobs)
 ^ 
 * History		:	NONE
 * */
defined('_JEXEC') or die();

// Load framework base classes
jimport('joomla.application.component.controller');

/**
 * Messaging Message Controller
 *
 */
class JBJobsControllerPayment extends JControllerLegacy {
	/**
	 * constructor (registers additional tasks to methods)
	 * @return void
	 */
	function __construct(){
		$user	= JFactory::getUser();
		if ($user->guest){
			// redirect user if not login
			$link = 'index.php?option=com_user';
			$this->setRedirect($link);
		}
		parent :: __construct();
	}
	
	function add(){
		//Set the right view
		$jinput = JFactory::getApplication()->input;
		$jinput->set( 'view', 'message' );
		parent::display();
	}
	
	function processpaymentmethod(){
		//clear the id set in the session after the checkout page
		$session = JFactory::getSession();
		$session->clear('id', 'upgsubscr');
		
		$jinput 	= JFactory::getApplication()->input;
		$post   	= $jinput->getArray($_POST);	
		$subscrid 	= $post['id'];
		$paymode 	= $jinput->get('paymode', '', 'string');
		$buy  		= $jinput->get('buy', '',  'string');	//either buy credit or plan
		$amount 	= $jinput->get('amount', 0, 'int');
		$Itemid 	= $jinput->get('Itemid',0,'int');
		
		//do not redirect to payment page in case of free plans
		if(empty($amount)){
			if($buy == 'plan')
				$link	= JRoute::_('index.php?option=com_jbjobs&view=membership&layout=planhistory&Itemid='.$Itemid, false);
			elseif($buy == 'credit')
				$link	= JRoute::_('index.php?option=com_jbjobs&view=membership&layout=credit_invoice&Itemid='.$Itemid, false);
			$this->setRedirect($link);
			return false;
		}

		if($paymode == '.paypal'){			 //paypal
			$this->paypalSubscr();
		}
		elseif($paymode == '.googleco'){	 // google checkout
			$this->googlecoSubscr();
		}
		elseif($paymode == '.authorizenet'){ // authorize.net
			$this->authorizenetSubscr();
		}
		elseif($paymode == '.moneybookers'){ // money bookers
			$this->moneybookersSubscr();
		}
		elseif($paymode == '.2checkout'){ 	 // 2checkout
			$this->pymt2Checkout();
		}
        elseif($paymode == '.Sn'){
            $this->snPay();
        }
		elseif($paymode == '.banktransfer'){ // Regular Bank Transfer
			if($buy == 'plan')
				$link	= JRoute::_('index.php?option=com_jbjobs&view=membership&layout=manual_subscr&id='.$subscrid.'&Itemid='.$Itemid, false);
			elseif($buy == 'credit')
				$link	= JRoute::_('index.php?option=com_jbjobs&view=membership&layout=manual_payment&id='.$subscrid.'&Itemid='.$Itemid, false);
			$this->setRedirect($link);
		}
	}
	
    /* Redirect To Bank */
    function snPay()
    {
        jimport('sncore.include');
        SNGlobal::loadLanguage('plg_system_sn_jbjobs',JPATH_ADMINISTRATOR);

        $app = JFactory::getApplication();

        $id = SNGlobal::getVar('id');
        $paymode = SNGlobal::getVar('paymode');
        $buy = SNGlobal::getVar('buy');
        $Itemid = SNGlobal::getVar('Itemid');
        $user =& JFactory::getUser();
        
        $details = $this->getPaymentDetails($id, $buy);
        $amount = intval($details['amount']);
        $taxRate = $details['taxrate'];
        $orderId = $details['orderid'];
        $itemname = $details['itemname'];
        $item_num = $details['item_num'];
        $invoiceNo = $details['invoiceNo'];
        
        $amount += $taxRate > 0 ? $taxRate*$amount/100 : 0;
        $backUrl = JRoute::_(JURI::base().'index.php?option=com_jbjobs&task=returnSnPay&controller=payment&oid='.$orderId.'&buy='.$buy.'&Itemid='.$Itemid);

        $query = "SELECT `params` FROM `#__extensions` WHERE `element`='sn_jbjobs'";
        $pluginParams = SNGlobal::selectByQuery($query,2);
        $pluginParams = !empty($pluginParams['params']) ? SNGlobal::jsonDecode($pluginParams['params']) : array();

        $pin = isset($pluginParams['sn_pin']) ? $pluginParams['sn_pin'] : '';
        $currency = isset($pluginParams['sn_currency']) ? $pluginParams['sn_currency'] : '';
        $sendPayerInfo = isset($pluginParams['sn_send_payer_info']) ? $pluginParams['sn_send_payer_info'] : '';

        $amount = SNApi::modifyPrice($amount,$currency);

        $data = array(
            'pin'=> $pin,
            'price'=> $amount,
            'callback'=> $backUrl,
            'order_id'=> $orderId,
            'description'=> '',
            'mobile'=> '',
        );

        list($status,$msg,$resultData) = SNApi::request($data,$sendPayerInfo,'jbjobs');

        if($status == true)
        {
            $data['bank_callback_details'] = $resultData['bank_callback_details'];
            $data['au'] = $resultData['au'];

            SNApi::clearData();
            SNApi::setData($data);

            $html = '<div class="sn-jbjobs-go-to-bank" style="direction: rtl; text-align: center;">'.JText::_('SN_CONNECTING_TO_PORTAL').'</div>';
            $html .= SNGlobal::postData($resultData['form_details']['action'],$resultData['form_details']['fields'],100);
            echo $html;
            die();
        }

        $msg = $msg;
        $app->enqueueMessage('<h5>'.$msg.'</h5>','error');
    }
    
    /* Do Sn Verify */
    function returnSnPay()
    {
        jimport('sncore.include');
        SNGlobal::loadLanguage('plg_system_sn_jbjobs',JPATH_ADMINISTRATOR);

        $app = JFactory::getApplication();

        $orderId = SNGlobal::getVar('oid','','int','request');
        $buy = SNGlobal::getVar('buy','');
        $au = SNGlobal::getVar('au','');
        $sessionData = SNApi::getData();

        $link = JURI::base();
        if($buy == 'plan')
        {
            $link = JRoute::_('index.php?option=com_jbjobs&view=membership&layout=planhistory', false);
        }
        elseif($buy == 'credit')
        {
            $link = JRoute::_('index.php?option=com_jbjobs&view=membership&layout=credit_invoice', false);
        }

        if(!empty($orderId) && !empty($au) && !empty($sessionData) && $sessionData['order_id'] == $orderId)
        {
            $bankData = array();
            foreach (!empty($sessionData['bank_callback_details']['params']) ? $sessionData['bank_callback_details']['params'] : array() as $bankParam)
            {
                $bankData[$bankParam] = !empty($_REQUEST[$bankParam]) ? $_REQUEST[$bankParam] : '';
            }

            $data = array (
                'pin' => $sessionData['pin'],
                'price' => $sessionData['price'],
                'order_id' => $sessionData['order_id'],
                'au' => $au,
                'bank_return' => $bankData,
            );

            list($status,$msg,$resultData) = SNApi::verify($data,'jbjobs');
            
            if($status == true)
            {
                if($buy == 'plan')
                {
                    $this->approveSubscription($orderId);
                }
                elseif($buy == 'credit')
                {
                    $this->approveCredit($orderId);
                }

                $bankAu = !empty($resultData['bank_au']) ? $resultData['bank_au'] : $au;
                $msg = '<h5>'.JText::_('SN_PAID_TRANSACTION').'</h5>';
                $msg = str_replace('{REF}',$bankAu,$msg);

                $app->redirect($link,$msg,'Message');
                die();
            }

        }

        $app->redirect($link,'<h5>'.JText::_('SN_UNPAID_TRANSACTION').'</h5>','Error');
    }
    
	//14.Paypal Subscription
	function paypalSubscr(){
		$jinput 	= JFactory::getApplication()->input;
		$id   		= $jinput->get('id', 0, 'int');
		$paymode 	= $jinput->get('paymode', '', 'string');
		$buy  		= $jinput->get('buy', '', 'string');	//either buy credit or plan
		$Itemid 	= $jinput->get('Itemid', 0 , 'int');
		$user = JFactory::getUser();
		
		$payconfig = $this->payConfig($paymode);
		$pptestmode 	= $payconfig['pptestmode'];
		$paypalEmail 	= $payconfig['paypalEmail'];
		$ppCurrency 	= $payconfig['ppCurrency'];
		
		$details = $this->getPaymentDetails($id, $buy);
		$amount = $details['amount'];	
		$taxrate = $details['taxrate'];
		$orderid = $details['orderid'];
		$itemname = $details['itemname'];
		$item_num = $details['item_num'];
		$invoiceNo = $details['invoiceNo'];
		
		$link_return = JRoute::_(JURI::base().'index.php?option=com_jbjobs&task=returnpaypal&controller=payment&oid='.$orderid.'&buy='.$buy.'&Itemid='.$Itemid);
		
		require_once(JPATH_SITE.DS.'components'.DS.'com_jbjobs'.DS.'gateways'.DS.'paypal.class.php');
		$paypal = new paypal_class; // initiate an instance of the class
		$paypal->paypal_url = ($pptestmode) ? 'https://www.sandbox.paypal.com/cgi-bin/webscr' : 'https://www.paypal.com/cgi-bin/webscr';
	
		$paypal->add_field('business', $paypalEmail);
		$paypal->add_field('return', $link_return);
		$paypal->add_field('cancel_return', JURI::base().'index.php?option=com_jbjobs&task=returnpaypal&controller=payment&oid='.$orderid.'&buy='.$buy.'&Itemid='.$Itemid);
		$paypal->add_field('notify_url', JURI::base().'index.php?option=com_jbjobs&task=returnpaypal&controller=payment&oid='.$orderid.'&buy='.$buy.'&Itemid='.$Itemid);
		$paypal->add_field('item_name', $itemname);
		$paypal->add_field('item_number', $item_num);
		$paypal->add_field('amount', $amount);
		$paypal->add_field('invoice', $invoiceNo);
		$paypal->add_field('no_note', "1");
		$paypal->add_field('no_shipping', "1");
		$paypal->add_field('currency_code', $ppCurrency);
		$paypal->add_field('tax_rate', $taxrate);
		$paypal->submit_paypal_post(); // submit the fields to paypal
	
		?>
		<script>
			document.paypal_form.submit();
		</script>
	<?php
	}
	
	//get the payment details that need to be sent to each payment
	function getPaymentDetails($id, $buy){
		$db = JFactory::getDBO();
		$details = array();
		if($buy == 'credit'){
			$row 	= JTable::getInstance('billing', 'Table');
			$row->load($id);
			
			$amount = $row->amount;	
			//$taxrate = $row->tax_percent;
			//$orderid = $row->id; 
			$itemname = JText::sprintf('JBJOBS_CREDIT_PURCHASE_MANY_CREDITS', $row->credit);
			//$item_num = $row->id;	// billing id of the credit purchase
			//$invoiceNo = $row->invoiceNo;	// invoice number of the payment
		}
		elseif($buy == 'plan'){
			$row 	= JTable::getInstance('plansubscr', 'Table');
			$row->load($id);
			
			if($row->user_type == 'e')
 				$planTblName = '#__jbjobs_plan';
 			elseif($row->user_type == 'j')
 				$planTblName = '#__jbjobs_plan_js';
			
			//@update 1.3.8 - return if plan is empty	
			if(empty($planTblName))
				return;	
			
			$query = "SELECT * FROM $planTblName WHERE id = ".$row->subscription_id;
			$db->setQuery($query);
			$plan = $db->loadObject();
			
			$amount = $row->price;
			//$taxrate = $row->tax_percent;
			//$orderid = $row->id;
			$itemname = JText::_('JBJOBS_SUBSCR_BUY').' - '.$plan->name;
			//$item_num = $row->id;	// subscr id of the plan purchased
			//$invoiceNo = $row->invoiceNo;	// invoice number of the payment
		}
		if (isset($row->id_country)) {
			$countryQry = "SELECT country FROM #__jbjobs_country WHERE id = ".$row->id_country;
			$db->setQuery($countryQry);
			$countryName = $db->loadResult();
			$details['country'] = $countryName;
			$details['city'] = $row->city;
			$details['state'] = $row->state;
		}
		$details['amount'] 	  = $amount;
		$details['taxrate']   = $row->tax_percent;
		$details['orderid']   = $row->id;
		$details['itemname']  = $itemname;
		$details['item_num']  = $row->id;
		$details['invoiceNo'] = $row->invoiceNo;
		//$details['address'] = $row->address;
		//$details['address_cont'] = $row->address_cont;
		//$details['country'] = $countryName;
		//$details['city'] = $row->city;
		//$details['state'] = $row->state;
		//$details['zip'] = $row->zip;
		//$details['phone'] = $row->phone;
		//$details['notes'] = $row->notes;
		
		return $details;
	}
	
	//15.Return Paypal 
	function returnPaypal(){
		$app 	= JFactory::getApplication();
		$jinput = JFactory::getApplication()->input;
		$oid 	= $jinput->get('oid', 0, 'int');
		$buy 	= $jinput->get('buy', '', 'string');
		$db 	= JFactory::getDBO();
	
		if($oid == ''){
			$msg = JText::_('JBJOBS_PAYMENT_NOT_PROCESSED');		
			$link = JRoute::_('index.php?option=com_jbjobs');	
			$this->setRedirect($link, $msg);
			return false;	
		}
		else {
			require_once(JPATH_SITE.DS.'components'.DS.'com_jbjobs'.DS.'gateways'.DS.'paypal.class.php');
			$paypal = new paypal_class; // initiate an instance of the class
	
			$payconfig = $this->payConfig('.paypal');
			$pptestmode = $payconfig['pptestmode'];
			$paypal->paypal_url = ($pptestmode) ? 'https://www.sandbox.paypal.com/cgi-bin/webscr' : 'https://www.paypal.com/cgi-bin/webscr';
	
			if ($paypal->validate_ipn()){
				if($buy == 'plan')
					$this->approveSubscription($oid);
				elseif($buy == 'credit')
					$this->approveCredit($oid);
					
				$msg = JText::sprintf('JBJOBS_PAYMENT_SUCCESSFUL', 'PayPal');
			}
			else {
				$msg = JText::_('JBJOBS_YOUR_PAYPAL_TRANSACTION_IS_CANCELLED');
			}
			
			if($buy == 'plan')
				$link = JRoute::_('index.php?option=com_jbjobs&view=membership&layout=planhistory', false);
			elseif($buy == 'credit')
				$link = JRoute::_('index.php?option=com_jbjobs&view=membership&layout=credit_invoice', false);
				
			$this->setRedirect($link, $msg);
		}
	}
	
	//14.Google Subscription
	function googlecoSubscr(){
		$db	 	 = JFactory::getDBO();
		$jinput  = JFactory::getApplication()->input;
		$id   	 = $jinput->get('id', 0, 'int');
		$paymode = $jinput->get('paymode', '', 'string');
		$buy  	 = $jinput->get('buy', '', 'post', 'string');	//either buy credit or plan
		$Itemid  = $jinput->get('Itemid', 0, 'int');
		$user    = JFactory::getUser();
		
		$payconfig = $this->payConfig($paymode);
		$gcotestmode 	= $payconfig['gctestmode'];
		$gcomerchantkey	= $payconfig['gcMerchantKey'];
		$gcomerchantid	= $payconfig['gcMerchantID'];
		$gcocurrency	= $payconfig['gcCurrency'];
		
		$details = $this->getPaymentDetails($id, $buy);
 		$amount = $details['amount'];	
 		$taxrate = $details['taxrate'];		//Google has its own tax settings and therefore passing tax has no effect.
 		$orderid = $details['orderid'];
 		$itemname = $details['itemname'];
 		$item_num = $details['item_num'];
		$invoiceNo = $details['invoiceNo'];
		
		$link_return = JURI::base().'index.php?option=com_jbjobs&task=thankspage&controller=payment&oid='.$orderid.'&buy='.$buy.'&Itemid='.$Itemid;
		require_once(JPATH_SITE.DS.'components'.DS.'com_jbjobs'.DS.'gateways'.DS.'googleco.class.php');
	
		$googleco = new googleco_class; // initiate an instance of the class
		$googleco->googleco_url = ($gcotestmode) ? 'https://sandbox.google.com/checkout/api/checkout/v2/checkoutForm/Merchant/'.$gcomerchantid : 'https://checkout.google.com/api/checkout/v2/checkoutForm/Merchant/'.$gcomerchantid;
	
		$privData = $orderid.';'.$buy;
		
		$googleco->add_field('item_name_1', $itemname);
		$googleco->add_field('item_description_1', $itemname);
		$googleco->add_field('item_price_1', $amount);
		$googleco->add_field('item_quantity_1', 1);
		$googleco->add_field('item_currency_1', $gcocurrency);
		$googleco->add_field('item_merchant_id_1', $invoiceNo);
		$googleco->add_field('continue_url', $link_return);
		$googleco->add_field('shopping-cart.merchant-private-data', $privData);
		//$googleco->add_field('tax_rate_#', 0.0125);
		
		$googleco->submit_googleco_post(); // submit the fields to Google Checkout
	
		?>
		<script>
			document.googleco_form.submit();
		</script>
	<?php
	}
	
	//15.Return Google Subscription
	function returnGoogleco(){
		
		require_once(JPATH_SITE.DS.'components'.DS.'com_jbjobs'.DS.'gateways'.DS.'googleco.class.php');
		$gco = new googleco_class;
		$response = $gco->validateNotification($_POST);
		if ($response['valid']){
			$priv = $response['order-id'];
			$arr = explode(';', $priv);
			
			$oid = $arr[0];
			$buy = $arr[1];
			if($buy == 'plan')
				$this->approveSubscription($oid);
			elseif($buy == 'credit')
				$this->approveCredit($oid);
				
			$msg = JText::sprintf('JBJOBS_PAYMENT_SUCCESSFUL', 'Google Checkout');
		}
		else {
			$msg = JText::_('JBJOBS_PAYMENT_ERROR').' - '.$response['pending_reason'];
		}
	}
	
	function authorizenetSubscr(){
		$db 	 = JFactory::getDBO();
		$jinput  = JFactory::getApplication()->input;
		$id   	 = $jinput->get('id', 0, 'int');
		$buy  	 = $jinput->get('buy', '', 'string');	//either buy credit or plan
		$paymode = $jinput->get('paymode', '', 'string');
		$Itemid  = $jinput->get('Itemid',0 ,'int');
		$user = JFactory::getUser();
		
		$payconfig = $this->payConfig($paymode);
		$authtestmode 	= $payconfig['authtestmode'];
		$authAPILogin	= $payconfig['authAPILogin'];
		$authTransKey	= $payconfig['authTransKey'];
		$authCurrency	= $payconfig['authCurrency'];
		
		$details = $this->getPaymentDetails($id, $buy);
 		$amount = $details['amount'];	
 		$taxrate = $details['taxrate']/100;
 		$totamt = (float)($amount + $amount*$taxrate);
 		$orderid = $details['orderid'];
 		$itemname = $details['itemname'];
 		$item_num = $details['item_num'];
		$invoiceNo = $details['invoiceNo'];
		
		$post_url = ($authtestmode) ? 'https://test.authorize.net/gateway/transact.dll' : 'https://secure.authorize.net/gateway/transact.dll';
		$link_return = JRoute::_(JURI::base().'index.php?option=com_jbjobs&task=returnauthorizenet&controller=payment&oid='.$orderid.'&buy='.$buy.'&Itemid='.$Itemid);
		require_once(JPATH_SITE.DS.'components'.DS.'com_jbjobs'.DS.'gateways'.DS.'AuthorizeNetSIM.php');
	
		$fp_timestamp = time();
		$fp_sequence = $item_num; // Enter an invoice or other unique number.
		$fingerprint = AuthorizeNetSIM_Form::getFingerprint($authAPILogin, $authTransKey, $totamt, $fp_sequence, $fp_timestamp);
		?>
		
		<form method='post' action="<?php echo $post_url; ?>" name="authorize_form">
			<input type='hidden' name="x_login" value="<?php echo $authAPILogin; ?>" />
			<input type='hidden' name="x_fp_hash" value="<?php echo $fingerprint; ?>" />
			<input type='hidden' name="x_description" value="<?php echo $itemname; ?>" />
			<input type='hidden' name="x_cust_id" value="<?php echo $user->username; ?>" />
			<input type='hidden' name="x_first_name" value="<?php echo $user->name; ?>" />
			<input type='hidden' name="x_email" value="<?php echo $user->email; ?>" />
			<input type='hidden' name="x_email_customer" value="TRUE" />
			<input type='hidden' name="x_amount" value="<?php echo $totamt; ?>" />
			<input type='hidden' name="x_invoice_num" value="<?php echo $invoiceNo; ?>" />
			<input type='hidden' name="x_tax" value="<?php echo $taxrate; ?>">
			<input type='hidden' name="x_fp_timestamp" value="<?php echo $fp_timestamp; ?>" />
			<input type='hidden' name="x_fp_sequence" value="<?php echo $fp_sequence; ?>" />
			<input type='hidden' name="x_version" value="3.1">
			<input type='hidden' name="x_show_form" value="payment_form">
			<input type='hidden' name="x_test_request" value="false" />
			<input type='hidden' name="x_method" value="cc">
			<input type='hidden' name="x_receipt_link_method" value="POST">
			<input type='hidden' name="x_receipt_link_text" value="Return to Merchant site">
			<input type='hidden' name="x_receipt_link_url" value="<?php echo $link_return; ?>">
			<?php echo JText::sprintf('JBJOBS_PAYMENT_REDIRECTION_PAGE', 'Authorize.net'); ?><br><br>
			<input type='submit' value="<?php echo JText::_('JBJOBS_PROCEED_FOR_PAYMENT'); ?>">
		</form>
		<script>
			document.authorize_form.submit();
		</script>
	<?php
 	}	
	
	//15.Return Authorize.Net
	function returnauthorizenet(){
		$jinput = JFactory::getApllication()->input;
		$oid 	= $jinput->get('oid', 0, 'string');
		$buy 	= $jinput->get('buy', '', 'string');
		$db 	= JFactory::getDBO();
		if($oid == ''){
			$msg = JText::_('JBJOBS_PAYMENT_NOT_PROCESSED');		
			$link = JRoute::_('index.php?option=com_jbjobs');	
			$this->setRedirect($link, $msg);
			return false;	
		}
		else {
			if ($_POST['x_response_code'] == 1){
				if($buy == 'plan')
					$this->approveSubscription($oid);
				elseif($buy == 'credit')
					$this->approveCredit($oid);
					
				$msg = JText::sprintf('JBJOBS_PAYMENT_SUCCESSFUL', 'Authorize.net');
			}
			else {
				$msg = JText::_('JBJOBS_PAYMENT_ERROR');
			}
		}
		if($buy == 'plan')
				$link = JRoute::_('index.php?option=com_jbjobs&view=membership&layout=planhistory', false);
			elseif($buy == 'credit')
				$link = JRoute::_('index.php?option=com_jbjobs&view=membership&layout=credit_invoice', false);
		$this->setRedirect($link, $msg);	
	}

	function moneybookersSubscr(){
		$db 	 = JFactory::getDBO();
		$jinput  = JFactory::getApplication()->input;
		$id   	 = $jinput->get('id', 0,  'int');
		$buy  	 = $jinput->get('buy', '',  'string');	//either buy credit or plan
		$paymode = $jinput->get('paymode', '', 'string');
		$Itemid  = $jinput->get('Itemid');
		$user    = JFactory::getUser();
		
		$payconfig 		= $this->payConfig($paymode);
		$paytoEmail 	= $payconfig['mbPaymentEmail'];
		$mbMerchantID	= $payconfig['mbMerchantID'];
		$mbSecret		= $payconfig['mbSecret'];
		$mbCurrency		= $payconfig['mbCurrency'];
		
		$details = $this->getPaymentDetails($id, $buy);
 		$amount = $details['amount'];	
 		$taxrate = $details['taxrate'];
 		$totamt = (float)($amount + $amount*($taxrate/100));
 		$orderid = $details['orderid'];
 		$itemname = $details['itemname'];
 		$item_num = $details['item_num'];
		$invoiceNo = $details['invoiceNo'];
		
		$prod_url = "https://www.moneybookers.com/app/payment.pl";
		$link_return = JURI::base().'index.php?option=com_jbjobs&task=returnMoneybookerssubscr&controller=payment&oid='.$orderid.'&buy='.$buy.'&Itemid='.$Itemid;
		$link_status = JURI::base().'index.php?option=com_jbjobs&task=statusmoneybookers&controller=payment&oid='.$orderid.'&buy='.$buy.'&Itemid='.$Itemid;
	?>	
	<form action="<?php echo $prod_url; ?>" name="mb_form">
		<input type="hidden" name="pay_to_email" value="<?php echo $paytoEmail; ?>">
		<input type="hidden" name="transaction_id" value="<?php echo $invoiceNo; ?>">
		<input type="hidden" name="return_url" value="<?php echo $link_return; ?>">
		<input type="hidden" name="return_url_target" value="1">
		<input type="hidden" name="cancel_url_target" value="1">
		<input type="hidden" name="status_url" value="<?php echo $link_status; ?>">
		<input type="hidden" name="status_url2" value="<?php echo $paytoEmail; ?>">
		<input type="hidden" name="dynamic_descriptor" value="Jobsite">
		<input type="hidden" name="language" value="EN">
		<input type="hidden" name="confirmation_note" value="We wish you have pleasure visiting our site again!">
		<input type="hidden" name="amount" value="<?php echo $totamt; ?>">
		<input type="hidden" name="currency" value="<?php echo $mbCurrency; ?>">
		<input type="hidden" name="detail1_description" value="Item Name:">
		<input type="hidden" name="detail1_text" value="<?php echo $itemname; ?>">
		<input type="hidden" name="rec_period" value="1">
		<input type="hidden" name="rec_grace_period" value="1">
		<input type="hidden" name="rec_cycle" value="day">
		<input type="hidden" name="ondemand_max_currency" value="EUR">
		<?php echo JText::sprintf('JBJOBS_PAYMENT_REDIRECTION_PAGE', 'Moneybookers'); ?><br><br>
		<input type="submit" name="Pay" value="<?php echo JText::_('JBJOBS_PROCEED_FOR_PAYMENT'); ?>">
	</form>
	<script>
		document.mb_form.submit();
	</script>
	<?php }
	
	function returnMoneybookerssubscr(){
		$msg = JText::_('JBJOBS_THANKS_FOR_PAYMENT');
		$jinput = JFactory::getApplication()->input;
		$oid 	= $jinput->get('oid', '', 'string');
		$buy 	= $jinput->get('buy', '', 'string');
		
		if($oid == ''){
				$msg = JText::_('JBJOBS_PAYMENT_NOT_PROCESSED');		
				$link = JRoute::_('index.php?option=com_jbjobs');	
				$this->setRedirect($link, $msg);
				return false;	
		}
		else {
			if($buy == 'plan')
				$link = JRoute::_('index.php?option=com_jbjobs&view=membership&layout=planhistory', false);
			elseif($buy == 'credit')
				$link = JRoute::_('index.php?option=com_jbjobs&view=membership&layout=credit_invoice', false);
		}
		$this->setRedirect($link, $msg);
		
	}
	
	function statusmoneybookers(){
		$post   = $jinput->getArray($_POST);	
		$db = JFactory::getDBO();
		$jinput = JFactory::getApplication()->input;
		$oid 	= $jinput->get('oid', '', 'string');
		$buy 	= $jinput->get('buy', '', 'string');
		
		$payconfig = $this->payConfig('.moneybookers');
		$mbSecret	= $payconfig['mbSecret'];
		
		if($oid == ''){
			$msg = JText::_('JBJOBS_PAYMENT_NOT_PROCESSED');		
			$link = JRoute::_('index.php?option=com_jbjobs');	
			$this->setRedirect($link, $msg);
			return false;	
		}
		else {
			$md5sig = md5( $post['merchant_id'].$post['transaction_id'].strtoupper(md5($mbSecret)).$post['mb_amount'].$post['mb_currency'].$post['status'] );
			$md5sig =  strtoupper($md5sig);
	
			if (($post['status'] == '2') && ($md5sig == $post['md5sig'])){
				if($buy == 'plan')
					$this->approveSubscription($oid);
				elseif($buy == 'credit')
					$this->approveCredit($oid);
					
				$msg = JText::sprintf('JBJOBS_PAYMENT_SUCCESSFUL', 'Moneybookers.com');
			}
			else {
				$msg = JText::_('JBJOBS_PAYMENT_ERROR');
			}
		}
	}
	
	function pymt2Checkout(){
		$db 	 = JFactory::getDBO();
		$jinput  = JFactory::getApplication()->input;		
		$id   	 = $jinput->get('id', 0, 'int');
		$buy  	 = $jinput->get('buy', '', 'string');	//either buy credit or plan
		$paymode = $jinput->get('paymode', '', 'string');
		$Itemid  = $jinput->get('Itemid',0,'int');
		$user 	 = JFactory::getUser();
		
		$payconfig = $this->payConfig($paymode);
		$testmode2co 	= $payconfig['2coTestmode'];
		$vendorid2co	= $payconfig['2coVendorid'];
		
		$details = $this->getPaymentDetails($id, $buy);
 		$amount = $details['amount'];	
 		$taxrate = $details['taxrate']/100;
 		$totamt = (float)($amount + $amount*$taxrate); $totamt = number_format($totamt, 2, '.', '');
 		$orderid = $details['orderid'];
 		$itemname = $details['itemname'];
 		$item_num = $details['item_num'];
		$invoiceNo = $details['invoiceNo'];
		
		$link_return = JRoute::_(JURI::base().'index.php?option=com_jbjobs&task=return2checkcout&controller=payment&oid='.$orderid.'&buy='.$buy.'&Itemid='.$Itemid);
		?>
		
		<form action="https://www.2checkout.com/checkout/purchase" method="post" name="co2_form">
			<p>
				<input type="hidden" name="sid" value="<?php echo $vendorid2co; ?>"/>
				<input type="hidden" name="cart_order_id" value="<?php echo $invoiceNo; ?>"/>
				<input type="hidden" name="total" value="<?php echo $totamt; ?>"/>
				<input type="hidden" name="c_prod_1" value="<?php echo $item_num; ?>"/>
				<input type="hidden" name="c_name_1" value="<?php echo $itemname; ?>"/>
				<input type="hidden" name="c_description_1" value="<?php echo $itemname; ?>"/>
				<input type="hidden" name="c_price_1" value="<?php echo $amount; ?>"/>
				<?php if($testmode2co){ ?>
				<input type="hidden" name="demo" value="Y"/>
				<?php }?>
				<input type="hidden" name="return_url" value="<?php echo $link_return; ?>"/>
				<input type="hidden" name="merchant_order_id" value="<?php echo $invoiceNo; ?>"/>
				<input type="hidden" name="skip_landing" value="1"/>
				<input type="hidden" name="x_receipt_link_url" value="<?php echo $link_return; ?>"/>
				<input type="hidden" name="card_holder_name" value="<?php echo $user->name; ?>"/>
				<input type="hidden" name="email" value="<?php echo $user->email; ?>"/>
				<input type="hidden" name="id_type" value="1"/>
				<input type="hidden" name="pay_method" value="CC"/>
				<input type="hidden" name="buy" value="<?php echo $buy; ?>"/>
				<input type="hidden" name="oid" value="<?php echo $orderid; ?>"/>
				<?php echo JText::sprintf('JBJOBS_PAYMENT_REDIRECTION_PAGE', '2Checkout'); ?><br><br>
				<input type='submit' value="<?php echo JText::_('JBJOBS_PROCEED_FOR_PAYMENT'); ?>">
			</p>
		</form>
		<script>
			document.co2_form.submit();
		</script>
	<?php
 	}	
	
	//15.Return 2CheckOut Subscription
	function return2Checkcout(){
		$oid 	= $_POST['oid'];
		$buy 	= $_POST['buy'];
		$db 	= JFactory::getDBO();
		
		$payconfig = $this->payConfig('.2checkout');
		$testmode2co 	= $payconfig['2coTestmode'];
		$secret2co 	= $payconfig['2coSecretword'];
		$vendorid2co 	= $payconfig['2coVendorid'];
		
		//calculate md5 hash to compare with the post 'key' - md5 ( secret word + vendor number + order number + total )
		if($testmode2co)
			$string_to_hash	= $secret2co.$vendorid2co.'1'.$_POST['total'];
		else
			$string_to_hash	= $secret2co.$vendorid2co.$_POST['order_number'].$_POST['total'];
		
		$check_key = strtoupper(md5($string_to_hash));
		
		
		if($oid == ''){
			$msg = JText::_('JBJOBS_PAYMENT_NOT_PROCESSED');		
			$link = JRoute::_('index.php?option=com_jbjobs');	
			$this->setRedirect($link, $msg);
			return false;	
		}
		else {
			if($check_key ==  $_POST['key']){
				if($buy == 'plan')
					$this->approveSubscription($oid);
				elseif($buy == 'credit')
					$this->approveCredit($oid);
					
				$msg = JText::sprintf('JBJOBS_PAYMENT_SUCCESSFUL', '2Checkout');
			}
			else {
				$msg = JText::_('JBJOBS_PAYMENT_ERROR');
			}
		}
		if($buy == 'plan')
			$link = JRoute::_('index.php?option=com_jbjobs&view=membership&layout=planhistory', false);
		elseif($buy == 'credit')
			$link = JRoute::_('index.php?option=com_jbjobs&view=membership&layout=credit_invoice', false);
		$this->setRedirect($link, $msg);	
	}
	
	function thanksPage(){
		$msg = JText::_('JBJOBS_THANKS_FOR_PAYMENT');
		$jinput = JFactory::getApplication()->input;
		$oid 	= $jinput->get('oid', '', 'string');
		$buy 	= $jinput->get('buy', '', 'string');
		
		if($oid == ''){
				$msg = JText::_('JBJOBS_PAYMENT_NOT_PROCESSED');		
				$link = JRoute::_('index.php?option=com_jbjobs');	
				$this->setRedirect($link, $msg);
				return false;	
		}
		else {
			if($buy == 'plan')
				$link = JRoute::_('index.php?option=com_jbjobs&view=membership&layout=planhistory', false);
			elseif($buy == 'credit')
				$link = JRoute::_('index.php?option=com_jbjobs&view=membership&layout=credit_invoice', false);
		}
		$this->setRedirect($link, $msg);
		
	}
	
	function approveSubscription($subscrid){
		$app = JFactory::getApplication();
		$db = JFactory::getDBO();
		$row	= JTable::getInstance('plansubscr', 'Table');
		$row->load($subscrid);
		
		if($row->user_type == 'e')
 				$planTblName = '#__jbjobs_plan';
 			elseif($row->user_type == 'j')
 				$planTblName = '#__jbjobs_plan_js';
		
		//@update 1.3.8 - return if empty		
		if(empty($planTblName))
			return;		
		
		$query = "SELECT p.* FROM $planTblName p WHERE p.id=".$row->subscription_id;
		$db->setQuery($query);
		$plan = $db->loadObject();
		
		// Update the transaction table if not approved
		if(!$row->approved){
		$transDtl = JText::_('JBJOBS_SUBSCR_BUY').' - '.$plan->name;
			$row_trans = JBJobsControllerJbjobs :: updateTransaction($row->user_id, $transDtl, $row->credit, 1);
		
		//save status subscription "approved"
		$date_expires = date("Y-m-d H:i:s", strtotime("+$plan->days $plan->days_type") + ($app->getCfg('offset') * 60 * 60));	
		$date_approve = date('Y-m-d H:i:s', time() + ($app->getCfg('offset') * 60 * 60));
		$row->approved = 1;
		$row->date_approval = $date_approve;
		$row->date_expire = $date_expires;
		$row->gateway_id = time();
		$row->trans_id = $row_trans->id;
		
		// pre-save checks
		if (!$row->check())
			JError::raiseError(500, $row->getError());
			
		// save the changes		
		if (!$row->store())
			JError::raiseError(500, $row->getError());		
		
		$row->checkin();	
		
			//alert the user and admin about the subscription
		JBJobsControllerJbjobs::alertAdminSubscr($row->id, $row->user_id);
		JBJobsControllerJbjobs::alertUserSubscr($row->id, $row->user_id);
	}
	}
	
	function approveCredit($billid){
		$app = JFactory::getApplication();
		$db  = JFactory::getDBO();
		$row = JTable::getInstance('billing', 'Table');
		$row->load($billid);
		
		// Update the transaction table if not approved
		if($row->approval != 'y'){
		$transDtl = JText::sprintf('JBJOBS_CREDIT_PURCHASE_MANY_CREDITS', $row->credit);
			$row_trans = JBJobsControllerJbjobs :: updateTransaction($row->user_id, $transDtl, $row->credit, 1);
		
		//save status billing "approved"		
		$row->approval ='y';
		$row->approval_date = $date_approve;
		$row->id_trans = $row_trans->id;
		
		// pre-save checks
		if (!$row->check())
			JError::raiseError(500, $row->getError() );
			
		// save the changes		
		if (!$row->store())
			JError::raiseError(500, $row->getError() );		
		
		$row->checkin();	
	}
	}
	
	function payConfig($paymode){
		$db = JFactory::getDBO();
		$query = "SELECT * FROM #__jbjobs_payment_mode WHERE gwcode='$paymode'";
		$db->setQuery($query);
		$config = $db->loadObjectList();
		
		$configs = array();
		foreach($config as $conf)	{
			$configs[$conf->fieldname] = $conf->savedvalue;	
		}
		return $configs;
	}
	
	function display($cachable = false, $urlparams = false){
		$document 	= JFactory :: getDocument();
		$jinput 	= JFactory::getApplication()->input;
		$viewName 	= $jinput->get('view', 'guest','string');
		$layoutName = $jinput->get('layout', 'showfront','string');
		
		$viewType 	= $document->getType();
		$view 		= $this->getView($viewName, $viewType); 
		$model 		= $this->getModel('jbjobs', 'JBJobsModel');
		if (!JError :: isError($model))
		{
			$view->setModel($model);
		}
		$view->setLayout($layoutName);
		$view->display();
	}

}
?>
