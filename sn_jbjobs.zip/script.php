<?php
defined('_JEXEC') or die('Restricted access');

jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder');

if(!defined('DS'))
{
    define('DS',DIRECTORY_SEPARATOR);
}

class plgSystemSn_jbjobsInstallerScript
{
    function preflight($type,$parent)
    {
        if(!JFolder::exists(JPATH_ADMINISTRATOR .DS. 'components' .DS. 'com_jbjobs'))
        {
            Jerror::raiseWarning(null,'لطفا ابتدا افزونه  جوم‌به (جی‌بی جابز) را نصب نمایید.');
            return false;
        }
    }

    function postflight($type,$parent)
    {
        /* Enable Plugin */
        $database = JFactory::getDBO();
        $query = "UPDATE `#__extensions` SET `enabled` = 1 WHERE `element` = 'sn_jbjobs'";
        $database->setQuery($query);
        $database->query();

        /* Move Libraries Files */
        $from = JPATH_ROOT .DS. 'plugins' .DS. 'system' .DS. 'sn_jbjobs' .DS. 'libraries' .DS;
        $to = JPATH_ROOT .DS. 'libraries' .DS;
        JFolder::copy($from,$to,'',true);

        if(JFolder::exists($from))
        {
            JFolder::delete($from);
        }

        $root = JPATH_ROOT .DS. 'plugins' .DS. 'system' .DS. 'sn_jbjobs' .DS. 'files' .DS. 'payment.php';
        $copy = JPATH_ROOT .DS. 'components' .DS. 'com_jbjobs' .DS. 'controllers' .DS. 'payment.php';

        if(JFile::exists($root))
        {
            JFile::copy($root,$copy,'',true);
            JFolder::delete(JPATH_ROOT .DS. 'plugins' .DS. 'system' .DS. 'sn_jbjobs' .DS. 'files');
        }

        if(strtolower($type) == 'install')
        {
            jimport('sncore.include');

            $id = '2350';
            $query = "SELECT COUNT(`id`) AS `count` FROM `#__jbjobs_payment_mode` WHERE `id`='".$id."'";
            $result = SNGlobal::selectByQuery($query);

            if(!empty($result['count']) && $result['count'] == 1)
            {
                $query = "DELETE FROM `#__jbjobs_payment_mode` WHERE `id`='".$id."'";
                SNGlobal::delete($query);
            }

            $name = 'پرداخت امن';
            $query = "INSERT INTO `#__jbjobs_payment_mode` VALUES ('".$id."','Sn','Sn','1','".$name."','','1','100','1','2','0','','Sn','.Sn','')";
            SNGlobal::insert($query);
        }
    }

    function uninstall($parent)
    {
        jimport('sncore.include');

        $id = '2350';

        $query = "DELETE FROM `#__jbjobs_payment_mode` WHERE `id`='".$id."'";
        SNGlobal::delete($query);
    }
}